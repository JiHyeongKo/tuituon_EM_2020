#include "button.h"

int main(void)
{
    startbutton();
}