#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include "led.h"

static unsigned int ledValue = 0;
static int fd = 0;

void doHelp(void)
{
	printf("ledtest <hex byte>: data bit0 operantion 1 => on, 0 => off\n");
	printf("	ledtest 0x05; 4th and 1th led on\n");
	printf("	ledtest 0xff; all led on\n");
	printf("	ledtest 0x00; all led off\n");
}

int ledOnOff (int ledNum, int onOff)
{
	int i=1;
	
	i = i<<ledNum;
	ledValue = ledValue& (~i);
	
	if (onOff !=0) 
		ledValue |= i;
		
	write (fd, &ledValue, 4);
}

int ledStatus (void)
{
	read(fd, &ledValue, 4);
	printf("ledStatus : %x\n", ledValue);

	return (unsigned int)ledValue;
}

int ledWrite(int data)
{
	printf("wrate data: 0x%X\n", data);
	write (fd, &data, 4);
}

int ledLibInit(void)
{
	fd=open(LED_DRIVER_NAME, O_RDWR);	
	if(fd < 0)
	{
		printf("Could not open the file\n");
		return 1;
	}
	ledValue = 0;
}
int ledLibExit(void)
{
	ledValue = 0;
	ledOnOff (0, 0);
	close(fd);
}

int ledOnAll(void)
{
	for(volatile int ledNum=0; ledNum<LED_MAX_NUM; ledNum++)
	{
		ledOnOff(ledNum, ON);
	}

	return ledValue;
}

int ledOffAll(void)
{
	for(volatile int ledNum=0; ledNum<LED_MAX_NUM; ledNum++)
	{
		ledOnOff(ledNum, OFF);
	}

	return ledValue;
}

int ledToggle(void)
{
	for(volatile int i=0; i<3; i++) // 3 times
	{
		ledOnAll();
		usleep(500*MSEC);	// 나중에 스레드로 최적화 필요
		ledOffAll();
		usleep(500*MSEC);
	}

	ledStatus();

	return ledValue;
}

int ledStair(int direction)
{
	ledOffAll();

	switch (direction)
	{
		case FORWARD:
			for(volatile int ledNum=0; ledNum<LED_MAX_NUM; ledNum++)
			{
				ledOnOff (ledNum, ON);
				usleep(500*MSEC);
				ledOnOff (ledNum, OFF);
				usleep(500*MSEC);
			}
			break;

		case REVERSE:
			for(volatile int ledNum=LED_MAX_NUM-1; ledNum>=0; ledNum--)
			{
				ledOnOff (ledNum, ON);
				usleep(500*MSEC);
				ledOnOff (ledNum, OFF);
				usleep(500*MSEC);
			}
			break;

		default:
			return -1;
	}

	return ledValue;
}

int ledStairBuffer(int direction)
{
	ledOffAll();

	switch (direction)
	{
		case FORWARD:	
			for(volatile int ledNum=0; ledNum<LED_MAX_NUM; ledNum++)
			{
				ledOnOff (ledNum, ON);
				usleep(500*MSEC);
			}
			break;

		case REVERSE:
			for(volatile int ledNum=LED_MAX_NUM-1; ledNum>=0; ledNum--)
			{
				ledOnOff (ledNum, ON);
				usleep(500*MSEC);
			}
			break;

		default:
			return -1;
	}
	
	ledOffAll();

	return ledValue;
}
