#ifndef _LED_H_
#define _LED_H_

#define LED_DRIVER_NAME "/dev/periled"
#define ON 1
#define OFF 0
#define MSEC 1000
#define LED_MAX_NUM 8
#define FORWARD 10
#define REVERSE 20

void doHelp(void);
int ledWrite(int data);
int ledLibInit(void);
int ledOnOff (int ledNum, int onOff);
int ledStatus (void);
int ledLibExit(void);
int ledOnAll(void);
int ledOffAll(void);
int ledToggle(void);
int ledStair(int direction);
int ledStairBuffer(int direction);
#endif
