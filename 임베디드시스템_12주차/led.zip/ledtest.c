#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <ctype.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include "led.h"

int main(int argc, char **argv)
{	
	unsigned int data = 0;
	int fd;
	if(argc < 2)
	{
		perror("Args number is less than 2\n");
		doHelp();
		return 1;
	}
	
	data = strtol(argv[1], NULL, 16);
	
	ledLibInit();
	ledWrite(data);	// if you don't want to use this fucntion, do not get arguments of main function.
	usleep(500*MSEC);
//	ledStatus();
//	ledOnOff(2, 1);
//	ledToggle();
//	ledStair(FORWARD);
//	ledStairBuffer(REVERSE);
	ledLibExit();
	
	return 0;
}
