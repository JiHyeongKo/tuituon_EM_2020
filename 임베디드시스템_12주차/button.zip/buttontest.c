#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <linux/input.h>
#include <unistd.h> // for open/close
#include <fcntl.h> // for O_RDWR
#include <sys/ioctl.h> // for ioctl
#include <sys/msg.h>
#include <pthread.h>
#include "button.h"
#include "../teamHW2_led/led.h"
// first read input device

int main(int argc, char *argv[])
{
	BUTTON_MSG_T msgrxdata;
	ledLibInit();
	buttonInit();
	
	while(1)
	{
		buttonGet(&msgrxdata);

		switch (msgrxdata.keyInput)
		{
			case KEY_HOME:          printf("ㄱ");	break;
            case KEY_SEARCH:       	printf("ㄴ");	 break;
            case KEY_BACK:          printf("ㄷ");    break;
            case KEY_MENU:          printf("ㄹ");    break;
            case KEY_VOLUMEDOWN:    ledOnAll();   break;
            case KEY_VOLUMEUP:      ledOffAll();   break;
            default: break;
		}

		msgrxdata.keyInput = 0;
	}

	buttonExit();
	ledLibExit();
}
