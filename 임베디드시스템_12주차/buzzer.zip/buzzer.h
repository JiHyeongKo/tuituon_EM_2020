#ifndef _BUZZER_H_
#define _BUZZER_H_

#define MAX_SCALE_STEP		8
#define BPM_STANDARD 60

int buzzerInit(int scale);
int buzzerExit(void);
void doHelp(void);
void buzzerPlaySong(int scale);
void buzzerstopSong(void);
void buzzerPlayMsec(int scale, int msec, double bpm);
void buzzerGoodBye(void);
#endif