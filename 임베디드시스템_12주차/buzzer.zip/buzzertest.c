#include <stdio.h>
#include <stdlib.h>
#include "buzzer.h"

int main(int argc , char **argv)
{
    int freIndex;

    if (argc < 2)
    {
        printf("Error!\n");
        doHelp();

        return 1;
    }

    freIndex = atoi(argv[1]);   // char -> integer

    if( buzzerInit(freIndex) )
        return -1;

    buzzerPlayMsec(freIndex, 1000, 128);
    buzzerExit();
    
    return 0;
}