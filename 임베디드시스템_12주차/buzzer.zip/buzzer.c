#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include <pthread.h>
#include "buzzer.h"

#define BUZZER_BASE_SYS_PATH	"/sys/bus/platform/devices/"
#define BUZZER_FILENAME		"peribuzzer"
#define	BUZZER_ENABLE_NAME	"enable"
#define BUZZER_FREQUENCY_NAME	"frequency"

char gBuzzerBaseSysDir[128];	// /sys/bus/platform/devices/peribuzzer.XX
const int musicScale[MAX_SCALE_STEP] = {262, 294, 330, 349, 392, 440, 494, 523};

int findBuzzerSysPath(void)
{
    DIR * dir_info = opendir(BUZZER_BASE_SYS_PATH);
    int ifNotFound = 1;
    if (dir_info != NULL)
    {
        while (1)
        {
            struct dirent *dir_entry;
            dir_entry = readdir (dir_info);

            if (dir_entry == NULL) 
                break;

            if (strncasecmp(BUZZER_FILENAME, dir_entry->d_name, strlen(BUZZER_FILENAME)) == 0)
            {
                ifNotFound = 0;
                sprintf(gBuzzerBaseSysDir,"%s%s/",BUZZER_BASE_SYS_PATH,dir_entry->d_name);
            }
        }
    }
    
    printf("find %s\n",gBuzzerBaseSysDir);
    return ifNotFound;
    } //버저 경로 찾기: /sys/bus/platform/devices/peribuzzer.XX 의 XX를 결정하는 것

void doHelp(void)
{
    printf("Usage:\n");
    printf("buzzertest <buzzerNo> \n");
    printf("buzzerNo: \n");
    printf("do(1),re(2),mi(3),fa(4),sol(5),ra(6),si(7),do(8) \n");
    printf("off(0)\n");
}

void buzzerEnable(int bEnable)
{
    char path[200];
    sprintf(path,"%s%s",gBuzzerBaseSysDir,BUZZER_ENABLE_NAME);
    int fd=open(path,O_WRONLY);
    
    if ( bEnable) 
            write(fd, &"1", 1);
    else 
            write(fd, &"0", 1);
            
    close(fd);
}

void setFrequency(int frequency)
{
    char path[200];
    sprintf(path,"%s%s",gBuzzerBaseSysDir,BUZZER_FREQUENCY_NAME);

    int fd=open(path,O_WRONLY);
    dprintf(fd, "%d", frequency);

    close(fd);
}

int buzzerInit(int scale)
{
    if( findBuzzerSysPath() )
    {
        printf ("ERROR! File Not Found!\r\n");
		return 1;
    }

    if (scale > MAX_SCALE_STEP || scale < 0)
    {
        doHelp();
        return -1;
    }

	return 0;
}

int buzzerExit(void)
{
    buzzerGoodBye();

    return 0;
}

void buzzerPlaySong(int scale)
{
    if ( scale > MAX_SCALE_STEP )
    {
        printf(" <buzzerNo> over range \n");
        doHelp();
    }

    if ( scale == 0)// disable
    {
        buzzerEnable(0);
    }

    else
    {
        printf("scale :%d \n", scale);
        setFrequency(musicScale[scale-1]);
        buzzerEnable(1);
    }
}

void buzzerStopSong(void)
{
    buzzerEnable(0);
}

void buzzerPlayMsec(int scale, int msec, double bpm)
{
    bpm = BPM_STANDARD / bpm;

    printf("scale :%d \n", scale);
    buzzerPlaySong(scale);
    usleep(bpm*msec*1000);
    buzzerEnable(0);
}

void buzzerGoodBye(void)
{
    buzzerPlayMsec(3, 250, 128);
    buzzerPlayMsec(5, 250, 128);
    buzzerPlayMsec(5, 500, 128);

    buzzerPlayMsec(5, 250, 128);
    buzzerPlayMsec(4, 250, 128);
    buzzerPlayMsec(3, 500, 128);

    buzzerPlayMsec(2, 250, 128);
    buzzerPlayMsec(2, 250, 128);
    buzzerPlayMsec(2, 250, 128);
    buzzerPlayMsec(3, 250, 128);

    buzzerPlayMsec(4, 250, 128);
    buzzerPlayMsec(3, 250, 128);
    buzzerPlayMsec(2, 500, 128);

    buzzerPlayMsec(0, 250, 128);
    buzzerPlayMsec(2, 250, 128);
    buzzerPlayMsec(2, 250, 128);
    buzzerPlayMsec(3, 250, 128);
    
    buzzerPlayMsec(4, 500, 128);
    buzzerPlayMsec(3, 250, 128);
    buzzerPlayMsec(2, 250, 128);

    buzzerPlayMsec(3, 1000, 128);
}