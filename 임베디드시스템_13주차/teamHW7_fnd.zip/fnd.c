#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <ctype.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <termios.h>
#include <fcntl.h>
#include <unistd.h>
#include "fnd.h"

#define FND_DRIVER_NAME "/dev/perifnd"

void doHelp(void)
{
	printf("Usage:\n");
	printf("fndtest option displayTimeSec displaynum [maxcounter]  >\n");
	printf("option   s  : static display  , displaynum range 0 ~ 999999\n");
	printf("option   t  ; time display  \n"); 
	printf("option   c  : counting from 0 to maxcounter .\n");
	printf("ex) fndtest s  1 1234  ; display  '1234'\n");
	printf("ex) fndtest t 3 ;display current time\n");
	printf("ex) fndtest c 2 100 ; display counting number  from  0  to  100\n");
}

int fndDisp(int num , int dotflag) //0-999999 숫자, 비트로 인코딩된 dot on/off
{
	int fd;
	int temp,i;
	stFndWriteForm stWriteData;
	for (i = 0; i < MAX_FND_NUM ; i++ )
	{
		stWriteData.DataDot[i] = (dotflag & (0x1 << i)) ? 1 : 0;
		stWriteData.DataValid[i] = 1;
	}
// if 6 fnd
	temp = num % 1000000; stWriteData.DataNumeric[0]= temp /100000;
	temp = num % 100000; stWriteData.DataNumeric[1]= temp /10000;
	temp = num % 10000; stWriteData.DataNumeric[2] = temp /1000;
	temp = num %1000; stWriteData.DataNumeric[3] = temp /100;
	temp = num %100; stWriteData.DataNumeric[4] = temp /10;
	stWriteData.DataNumeric[5] = num %10;
	fd = open(FND_DRIVER_NAME,O_RDWR);
	if ( fd < 0 )
	{
		perror("driver open error.\n");
		return 0;
	}
	write(fd, &stWriteData, sizeof(stFndWriteForm));
	close(fd);
	return 1;
}

int fndInit(int argc, char **argv)
{
	int fd;
	int mode ;
	int number,counter;
	
	if (argc <  2)
	{
		perror(" Args number is less than 2\n");
		doHelp();
		return 1;
	}
	
	if ( argv[1][0] == 's'  )
	{
		mode = MODE_STATIC_DIS;
		number = atoi(argv[2]);
	}
	
	else if ( argv[1][0] == 't'  )
	{
		mode = MODE_TIME_DIS;
	}
	
	else if ( argv[1][0] == 'c'  )
	{
		mode = MODE_COUNT_DIS;
		number = atoi(argv[2]);
	}
	
	else
	{
		doHelp();
		perror("option error \n");
		return 1;
	}
	printf("number :%d\n",number);
	
	if (mode == MODE_STATIC_DIS )
	{
		fndDisp(number , 0);
	}
	else if(mode == MODE_TIME_DIS )
	{
		struct tm *ptmcur;
		time_t tTime;
		if ( -1 == time(&tTime) )
			return -1;
		ptmcur = localtime(&tTime);
		number = ptmcur->tm_hour * 10000;
		number += ptmcur->tm_min *100;
		number += ptmcur->tm_sec;
		fndDisp(number , 0b1010);
	}
	else if (mode == MODE_COUNT_DIS)
	{
		counter = 0;
		while(1)
		{
			if (!fndDisp(counter , 0))
				break;
			counter++;
			sleep(1);
			if (counter > number )
				break;
		}
	}
	return 0;
}
