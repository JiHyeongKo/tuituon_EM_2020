#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include "lcdtext.h"

int main(int argc , char **argv)
{
    writeText(argc, argv);
    
    return 0;
}

