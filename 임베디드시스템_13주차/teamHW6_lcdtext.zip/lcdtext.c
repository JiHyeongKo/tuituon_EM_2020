#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <ctype.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include "lcdtext.h"

void doHelp()
{
	printf("usage: textlcdtest <linenum> opt: <'string'>\n");
	printf("       linenum => 0 ~ 2\n");
    printf("       or 't' for get current time\n");	
	printf("  ex) textlcdtest 1 'test hello' -> write line 1\n");
    printf("  ex) textlcdtest 2 -> erase line 2\n");
    printf("  ex) textlcdtest t -> present time\n");
}

int writeText(int argc, char **argv)  //arg 받아서 쓰는 함수
{
    unsigned int lineNum = 0;
    stTextLCD stlcd;    // stTextLCD struct - driver & interface
    int fd;
    int len;

    memset(&stlcd, 0, sizeof(stTextLCD));

    if(argc == 2)
    {
        if (strcmp(argv[1], "t") == 0)
        {
            timeText();
        }

        else
        {
            lineNum = strtol(argv[1], NULL, 10);
            eraseText(lineNum);
        }

        return 0;
    }

    else if(argc < 2)
    {
        perror("Args number is less than 1\n");
        doHelp();
        return 1;
    }

    lineNum = strtol(argv[1], NULL, 10);
    printf("Write lineNum: %d\n", lineNum);

    if(lineNum == 1)
        stlcd.cmdData = CMD_DATA_WRITE_LINE_1;

    else if (lineNum == 2)
        stlcd.cmdData = CMD_DATA_WRITE_LINE_2;

    else
    {
        printf("lineNume: %d wrong. range (1 ~ 2)\n", lineNum);
        return 1;
    }

    printf("string:%s\n",argv[2]);
    len = strlen(argv[2]);

    if(len > COLUMN_NUM)
        memcpy(stlcd.TextData[stlcd.cmdData - 1], argv[2], COLUMN_NUM);

    else
        memcpy(stlcd.TextData[stlcd.cmdData - 1], argv[2], len);

    stlcd.cmd = CMD_WRITE_STRING;
    
    fd = open(TEXTLCD_DRIVER_NAME, O_RDWR); // open driver
    if(fd < 0)
    {
        perror("driver (//dev//peritextlcd) open error\n");
        return 1;
    }

    write(fd, &stlcd, sizeof(stTextLCD));
    close(fd);
    return 0;
}

int eraseText(unsigned int lineNum)
{
    stTextLCD stlcd;    // stTextLCD struct - driver & interface
    int fd;
    int len = strlen("");
    memset(&stlcd, 0, sizeof(stTextLCD));

    stlcd.cmd = CMD_WRITE_STRING;

    printf("Erase lineNum: %d\n", lineNum);

    if(lineNum == 1)
        stlcd.cmdData = CMD_DATA_WRITE_LINE_1;

    else if (lineNum == 2)
        stlcd.cmdData = CMD_DATA_WRITE_LINE_2;

    else
    {
        printf("lineNume: %d wrong. range (1 ~ 2)\n", lineNum);
        return 1;
    }
    
    memcpy(stlcd.TextData[stlcd.cmdData - 1],"\n",len);

    fd = open(TEXTLCD_DRIVER_NAME, O_RDWR); // open driver
    if(fd < 0)
    {
        perror("driver (//dev//peritextlcd) open error\n");
        return 1;
    }

    write(fd, &stlcd, sizeof(stTextLCD));
    close(fd);

    return 0;
}

int outputText(unsigned int lineNum, char *writeBuffer)  // 바로 쓰는 함수
{
    stTextLCD stlcd;    // stTextLCD struct - driver & interface
    int fd;
    int len;

    memset(&stlcd, 0, sizeof(stTextLCD));

    printf("Write lineNum: %d\n", lineNum);

    if(lineNum == 1)
        stlcd.cmdData = CMD_DATA_WRITE_LINE_1;

    else if (lineNum == 2)
        stlcd.cmdData = CMD_DATA_WRITE_LINE_2;

    else
    {
        printf("lineNume: %d wrong. range (1 ~ 2)\n", lineNum);
        return 1;
    }

    printf("string:%s\n",writeBuffer);
    len = strlen(writeBuffer);
    printf("%d\n", len);
    if(len > COLUMN_NUM)
        memcpy(stlcd.TextData[stlcd.cmdData - 1], writeBuffer, COLUMN_NUM);

    else
        memcpy(stlcd.TextData[stlcd.cmdData - 1], writeBuffer, len);

    stlcd.cmd = CMD_WRITE_STRING;
    
    fd = open(TEXTLCD_DRIVER_NAME, O_RDWR); // open driver
    if(fd < 0)
    {
        perror("driver (//dev//peritextlcd) open error\n");
        return 1;
    }

    write(fd, &stlcd, sizeof(stTextLCD));
    close(fd);
    return 0;
}

int timeText(void)  // 시간 나오는 함수
{
    struct tm *localtime( const time_t *timer );
    struct tm *date; 
    const time_t t = time(NULL); 
    date = localtime(&t); 

    char year[5];
    char mon[3];
    char day[3];
    char hour[3];
    char min[3];
    char sec[3];
    char line_one[COLUMN_NUM] ={0,};
    char line_two[COLUMN_NUM] ={0,};

    sprintf(year, "%04d", date->tm_year+1900);
    sprintf(mon, "%02d", date->tm_mon+1);
    sprintf(day, "%02d", date->tm_mday);
    sprintf(hour, "%02d", date->tm_hour);
    sprintf(min, "%02d", date->tm_min);
    sprintf(sec, "%02d", date->tm_sec);

    strcat(line_one, year);
    strcat(line_one, "/");
    strcat(line_one, mon);
    strcat(line_one, "/");
    strcat(line_one, day);

    strcat(line_two, hour);
    strcat(line_two, ":");
    strcat(line_two, min);
    strcat(line_two, ":");
    strcat(line_two, sec);

    printf("%s\n", line_one);

    outputText(1, line_one);
    outputText(2, line_two);

    return 0;

    /*
    struct tm 
    { 
        int tm_sec; // 초 - [0～61] （閏秒を考慮） 
        int tm_min; /* 분 - [0～59] 
        int tm_hour; /* 시 - [0～23]
        int tm_mday; /* 일 - [1～31] 
        int tm_mon; /* 월 - [0～11] 
        int tm_year; /* 1900부터의 년 
        int tm_wday; /* 일요일부터의 요일 - [0～6] 
        int tm_yday; /* 년초부터의 통산 일수 - [0～365] 
        int tm_isdst; /* 서머 타임이 유효하면 양수, 유효하지 않으면 0, 불명이면 음수
    };
    */
}

    

