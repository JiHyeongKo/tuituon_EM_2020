#ifndef _ACCEL_MAG_GYRO_H_
#define _ACCEL_MAG_GYRO_H_
#define ALLOW_FIGURE        15000   // 이거보다 크면 rotation 돌아간 것으로 판별   
#define ALLOW_FIGURE_INV    -15000  // 이거보다 작으면 역방향 rotation 돌아간 것으로 판별
#define ROTATION_DEFAULT        0   // 기본 로테이션
#define ROTATION_HOR_FORWARD    1   // 정방향 가로
#define ROTATION_HOR_INVERSE    2   // 역방향 가로
#define ROTATION_VER_FORWARD    3   // 정방향 세로
#define ROTATION_VER_INVERSE    4   // 역방향 세로
#define pi	3.14	//파이 정의

void readAccel(int *accel); //Accelerometer
void readMag(int *mag);  //Magnetometer
void readGyro(int *gyro);  //Gyroscope
int rotation(int *accel);   // rotation
int compass(int *mag);  // compass
#endif
