#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <math.h>	//나침반
#include "accelMagGyro.h"
#define ACCELPATH   "/sys/class/misc/FreescaleAccelerometer/"
#define MAGNEPATH   "/sys/class/misc/FreescaleMagnetometer/"
#define GYROPATH    "/sys/class/misc/FreescaleGyroscope/"

void readAccel(int *accel) //Accelerometer
{
    int fd = 0;
    FILE *fp = NULL;

    fd = open (ACCELPATH "enable", O_WRONLY);
    dprintf(fd, "1");
    close(fd);
    fp = fopen(ACCELPATH "data", "rt");

    int accelBuffer[3];   // 3 axixs

    fscanf(fp, "%d, %d, %d", &accelBuffer[0], &accelBuffer[1], &accelBuffer[2]);
    printf("I read Accell %d, %d, %d\r\n", accelBuffer[0], accelBuffer[1], accelBuffer[2]);

    memcpy(accel, accelBuffer, sizeof(accelBuffer));
}

void readMag(int *mag)  //Magnetometer
{
    int fd = 0;
    FILE *fp = NULL;

    fd = open (MAGNEPATH "enable", O_WRONLY);
    dprintf(fd, "1");
    close(fd);
    fp = fopen(MAGNEPATH "data", "rt");

    int magBuffer[3];   // 3 axixs

    fscanf(fp, "%d, %d, %d", &magBuffer[0], &magBuffer[1], &magBuffer[2]);
    printf("I read Mag %d, %d, %d\r\n", magBuffer[0], magBuffer[1], magBuffer[2]);

    memcpy(mag, magBuffer, sizeof(magBuffer));
}

void readGyro(int *gyro)  //Gyroscope
{
    int fd = 0;
    FILE *fp = NULL;

    fd = open (GYROPATH "enable", O_WRONLY);
    dprintf(fd, "1");
    close(fd);
    fp = fopen(GYROPATH "data", "rt");

    int gyroBuffer[3];   // 3 axixs

    fscanf(fp, "%d, %d, %d", &gyroBuffer[0], &gyroBuffer[1], &gyroBuffer[2]);
    printf("I read Gyro %d, %d, %d\r\n", gyroBuffer[0], gyroBuffer[1], gyroBuffer[2]);

    memcpy(gyro, gyroBuffer, sizeof(gyroBuffer));
}

int compass(int *mag)   // 나침반
{
    //자기센서의 x,y값을 가지고 방향을 나타낸다. x=mag[0]	y=mag[1]이다.
    //방향이 0도면 북쪽, 180도면 남쪽, 90도면 동쪽, 270도면 서쪽을 나타낸다.
    int Direction = 0;
    double arctan = atan2((double)mag[0], (double)mag[1]);		//왜인지 아크탄젠트값이 
    printf("artan: %lf\n",arctan);							//0으로만 나온다..... 이건 나중에 arctan 함수를 다시 짜든가...ㅠㅠ
 
    if (mag[1]>0)
		Direction = 90 - (int)(arctan*180.0/pi);

	else if (mag[1] <0)
		Direction = 270 - (int)(arctan*180.0/pi);

	else {
		if(mag[0]>0)
			Direction = 0;
		else
			Direction = 180;
	}

	return Direction;
}

int rotation(int *accel) // 돌아간 방향 알려주는 함수. gyro 보다 accel이 중요하다.
{
    int rotation=0;

    if((accel[2] > ALLOW_FIGURE) || (accel[2] < ALLOW_FIGURE_INV))    // 하늘을 보거나 뒤집혀있다.
        {
            rotation = ROTATION_DEFAULT;
        }

    else if(accel[0] > ALLOW_FIGURE)   // 정방향 가로
        {
            rotation = ROTATION_HOR_FORWARD;
        }

    else if(accel[0] < ALLOW_FIGURE_INV)   // 역방향 가로
        {
            rotation = ROTATION_HOR_INVERSE;
        }

    else if(accel[1] > ALLOW_FIGURE)   // 정방향 세로
        {
            rotation = ROTATION_VER_FORWARD;
        }

    else if(accel[1] < ALLOW_FIGURE_INV)   // 역방향 세로
        {
            rotation = ROTATION_VER_INVERSE;
        }

    else
        {
            rotation = ROTATION_DEFAULT;
        }

    return rotation;
}
