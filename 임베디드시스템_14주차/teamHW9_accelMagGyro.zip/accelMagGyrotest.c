#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include "accelMagGyro.h"

int main(void)
{
    int accel[3];
    int mag[3];
    int gyro[3];
    int rotationBuffer = 0;
    int direction;

    readAccel(accel);
    readMag(mag);
    readGyro(gyro);
    
    direction = compass(mag);
    printf("direction : %d\n", direction);

    while(1)
    {
        readAccel(accel);
        rotationBuffer = rotation(accel);
        switch (rotationBuffer)
        {
        case ROTATION_DEFAULT: printf("기본\n");
            break;
        
        case ROTATION_HOR_FORWARD: printf("정방향 가로\n");
            break;

        case ROTATION_HOR_INVERSE: printf("역방향 가로\n");
            break;

        case ROTATION_VER_FORWARD: printf("정방향 세로\n");
            break;

        case ROTATION_VER_INVERSE: printf("역방향 세로\n");
            break;

        default:
            break;
        }
        
        usleep(500000);  // 0.5초마다 측정
    }

    return 0;
}
