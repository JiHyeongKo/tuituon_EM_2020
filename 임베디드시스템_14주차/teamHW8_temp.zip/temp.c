#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <getopt.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/types.h>
#include <linux/spi/spidev.h>
#define SPI_FILE_NAME   "/dev/spidev1.0"

char gBuf[10];

int spi_init(char filename[40])
{
	int file;
	__u8  mode, lsb, bits;
	__u32 speed=20000;

	if ((file = open(filename,O_RDWR)) < 0)
	{
		printf("Failed to open the bus.");
		/* ERROR HANDLING; you can check errno to see what went wrong */
		//printf ("ErrorTYpe:%d\r\n",errno);
		exit(1);
	}

	mode |= SPI_3WIRE ; 

	if (ioctl(file, SPI_IOC_RD_MODE, &mode) < 0)
	{
		perror("SPI rd_mode");
		return 0;
	}
	if (ioctl(file, SPI_IOC_RD_LSB_FIRST, &lsb) < 0)
	{
		perror("SPI rd_lsb_fist");
		return 0;
	}
	if (ioctl(file, SPI_IOC_RD_BITS_PER_WORD, &bits) < 0) 
	{
		perror("SPI bits_per_word");
		return 0;
	}
 
    printf("%s: spi mode %d, %d bits %sper word, %d Hz max\n",filename, mode, bits, lsb ? "(lsb first) " : "", speed); 
    return file;
}

char * spi_read_lm74(int file)
{
	int len;

	memset(gBuf, 0, sizeof( gBuf));
	len = read(file, gBuf, 2);
	if (len !=2)
	{
		perror("read error");
		return NULL;
	}

	return gBuf;
}

int temp_read(void)
{
    char *buffer;
	int file;
	 
	file=spi_init(SPI_FILE_NAME); //dev

	buffer=(char *)spi_read_lm74(file); 
	 
	close(file);

	int value = (buffer[0] << 8 ) | buffer[1];
	if ( value < 0 )
	{
		value = (int)(value^(-1));
	}
	value >>= 7; // unit 1 
	printf("%d \n", value);
}