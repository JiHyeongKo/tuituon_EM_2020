#ifndef _TEMP_H_
#define _TEMP_H_

int spi_init(char filename[40]);
char * spi_read_lm74(int file);
int temp_read(void);

#endif