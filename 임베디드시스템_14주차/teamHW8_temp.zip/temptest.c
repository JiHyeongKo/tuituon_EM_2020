#include "temp.h"

int main(int argc, char **argv)
{
	temp_read();
}